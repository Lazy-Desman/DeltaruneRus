— Титры —
Наша группа ВК: https://vk.com/lazydesman
Telegram: https://t.me/lazydesman
Discord: https://discord.gg/7pDZRVBB3Y
Tiktok: https://tiktok.com/@lazydesman
Поддержать команду рублём: https://boosty.to/lazydesman

Глава перевода (и по совместительству кодер) — Неприм
Главный помогатор — DubstepDude
Талисман — Паскаль
Работа с видео и звуком — snus, geefel, SerTune9
Разработка установщика — Царь Всея Печенья, VladStepu2001

— Переводчики —
Niko the Nikobold
Arthis1
MelT
Holeg
Marine367
shywert
taydanto
4cB
Undead
derpyshy
ricurn

— Перерисовка графики —
snus
Rey Ven
Иван Сидоров
MelT
taydanto
DubstepDude
puskanyaww
Catptapathy
C-arth
SlavaWOW

— Бета-тестеры —
geniusfilmmaker
Goosepost
VistHJ 
TA1LS 
sanko

Бывшие участники перевода (со времён 1&2 глав):
Arty0m
nynxx
BohKorzh
Madworld

Особые благодарности:
Дмитрий Сыендук — голос мистера (Ант) Тенны
Folk — голос Джевила
Александра «Отголосок | Aka |» Кириченко — вокал «Не забудь»
geefel — «БОЙ»
Kit&Wei — «РАУНД», голос Диспетчера задачей
MishaGold — звуки кнопок