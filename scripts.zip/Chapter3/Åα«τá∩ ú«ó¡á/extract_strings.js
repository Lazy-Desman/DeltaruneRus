const fs = require("fs")

let chapter = 3
let en_strs = {missing: {}, odd: {}}

let cur_strings = require(`../Очистка строк/lang_en_${chapter}.json`)

for (let file of fs.readdirSync("./CodeEntries")) {
    let code = fs.readFileSync("./CodeEntries/" + file, "utf-8")
    // console.log(code)

    for (let match of code.matchAll(/loc\(.*?"(.*?)",.*"(.*?)"\)/g)) {
        let m = match[1]
            .replace(/\\n/g, "\n")
            .replace(/\\t/g, "\t")
            .replace(/\\"/g, "\"")
            .replace(/\\\\/g, "\\")
        let key = match[2]

        if (!cur_strings[key])
            en_strs.missing[key] = m
        else if (cur_strings[key] != m)
            en_strs.odd[key] = m
    }
}

fs.writeFileSync(`missed.json`, JSON.stringify(en_strs, null, 4))