const fs = require("fs")

let string_to_get = /c_tenna_sprite\(\d*?\)/

let chapter = 3
let folder_path = `../OriginalCode${chapter}/`
let folder = fs.readdirSync(folder_path)

let files = []

for (let f of folder) {
    let strs = fs.readFileSync(folder_path + f, "utf-8")

    if (strs.match(string_to_get)) {
        files.push(f.substring(0, f.length - 4))
    }
}

files = files.filter((f) => !f.endsWith("_old"))

console.log(files)